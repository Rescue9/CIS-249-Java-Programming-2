//package Ch32.Lab1;

import java.awt.*;
import javax.swing.*;
import java.util.*;

public class StillClock extends JPanel{

	private static final long serialVersionUID = 1L; // eclipse complains
	
	private int hour;
	private int minute;
	private int second;
	private boolean hourHandVisible = true;
	private boolean minuteHandVisible = true;
	private boolean secondHandVisible = true;
	
	/** Construct the default clock with the current time*/
	public StillClock(){
		setCurrentTime();
	}
	
	/** Construct a clock with a specific hour, minute, and second*/
	public StillClock(int hour, int minute, int second){
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}
	
	/** Return hour*/
	public int getHour(){
		return hour;
	}
	
	/** Set a different hour*/
	public void setHour(int hour){
		this.hour = hour;
		repaint();
	}
	
	/** Return minute*/
	public int getMinute(){
		return minute;
	}
	
	/** Set a different minute*/
	public void setMinute(int minute){
		this.minute = minute;
		repaint();
	}
	
	/** Return second*/
	public int getSecond(){
		return second;
	}
	
	public void setSecond(int second){
		this.second = second;
		repaint();
	}
	
	/** Draw the clock */
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		
		// initialize clock parameters
		int clockRadius = (int) (Math.min(getWidth(), getHeight())* 0.8 * 0.5);
		int xCenter = getWidth() / 2;
		int yCenter = getHeight() / 2;
		
		// draw circle
		g.setColor(Color.black);
		g.drawOval(xCenter - clockRadius, yCenter - clockRadius, 2 * clockRadius, 2 * clockRadius);
		g.drawString("12", xCenter - 5, yCenter - clockRadius + 12);
		g.drawString("9", xCenter - clockRadius + 3, yCenter + 5);
		g.drawString("3", xCenter + clockRadius - 10, yCenter + 3);
		g.drawString("6", xCenter - 3, yCenter + clockRadius - 3);
		
		// draw second hand
		if (secondHandVisible){
			int sLength = (int)(clockRadius * 0.8);
			int xSecond = (int)(xCenter + sLength * Math.sin(second * (2 * Math.PI / 60)));
			int ySecond = (int)(yCenter - sLength * Math.cos(second * (2 * Math.PI / 60)));
			g.setColor(Color.red);
			g.drawLine(xCenter, yCenter, xSecond, ySecond);
		}
		
		// draw minute hand
		if(minuteHandVisible){
			int mLength = (int)(clockRadius * 0.65);
			int xMinute = (int)(xCenter + mLength * Math.sin(minute * (2 * Math.PI / 60)));
			int yMinute = (int)(yCenter - mLength * Math.cos(minute * (2 * Math.PI / 60)));
			g.setColor(Color.blue);
			g.drawLine(xCenter, yCenter, xMinute, yMinute);
		}
		
		if(hourHandVisible){
			int hLength = (int)(clockRadius * 0.5);
			int xHour = (int)(xCenter + hLength * Math.sin((hour % 12 + minute / 60.0) * (2 * Math.PI / 12)));
			int yHour = (int)(yCenter - hLength * Math.cos((hour % 12 + minute / 60.0) * (2 * Math.PI / 12)));
			g.setColor(Color.green);
			g.drawLine(xCenter, yCenter, xHour, yHour);
		}
	}
	
	public void setCurrentTime(){
		// construct a calendar for the current date and time
		Calendar calendar = new GregorianCalendar();
		
		// set current hour minute and second
		this.hour = calendar.get(Calendar.HOUR_OF_DAY);
		this.minute = calendar.get(Calendar.MINUTE);
		this.second = calendar.get(Calendar.SECOND);
	}
	
	public Dimension getPreferredSize(){
		return new Dimension(200, 200);
	}
	
	public boolean isHourHandVisible(){
		return hourHandVisible;
	}
	
	public boolean isMinuteHandVisible(){
		return minuteHandVisible;
	}
	
	public boolean isSecondHandVisible(){
		return secondHandVisible;
	}
	
	public void setHourHandVisible(boolean hourHandVisible){
		this.hourHandVisible = hourHandVisible;
		repaint();
	}
	
	public void setMinuteHandVisible(boolean minuteHandVisible){
		this.minuteHandVisible = minuteHandVisible;
		repaint();
	}
	
	public void setSecondHandVisible(boolean secondHandVisible){
		this.secondHandVisible = secondHandVisible;
		repaint();
	}
}
